const admin = require('firebase-admin');
const logger = require('../utils/logger');

let firebaseApp;

const initializeFirebase = () => {
  try {
    // Check if already initialized
    if (admin.apps.length > 0) {
      logger.info('Firebase Admin already initialized');
      return admin.app();
    }

    // Option 1: Use service account file
    if (process.env.FIREBASE_SERVICE_ACCOUNT_PATH) {
      const serviceAccount = require(process.env.FIREBASE_SERVICE_ACCOUNT_PATH);
      
      firebaseApp = admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
        projectId: process.env.FIREBASE_PROJECT_ID,
      });
      
      logger.info('Firebase Admin initialized with service account file');
    } 
    // Option 2: Use environment variables
    else {
      const privateKey = process.env.FIREBASE_PRIVATE_KEY
        ? process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n')
        : undefined;

      if (!privateKey || !process.env.FIREBASE_CLIENT_EMAIL || !process.env.FIREBASE_PROJECT_ID) {
        throw new Error('Missing required Firebase Admin SDK environment variables');
      }

      firebaseApp = admin.initializeApp({
        credential: admin.credential.cert({
          projectId: process.env.FIREBASE_PROJECT_ID,
          privateKey: privateKey,
          clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        }),
        projectId: process.env.FIREBASE_PROJECT_ID,
      });

      logger.info('Firebase Admin initialized with environment variables');
    }

    return firebaseApp;
  } catch (error) {
    logger.error('Error initializing Firebase Admin:', error.message);
    throw error;
  }
};

// Verify Firebase ID Token
const verifyIdToken = async (idToken) => {
  try {
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    return decodedToken;
  } catch (error) {
    logger.error('Token verification error:', error.message);
    throw new Error('Invalid or expired token');
  }
};

// Set custom user claims (roles)
const setUserRole = async (uid, role) => {
  try {
    await admin.auth().setCustomUserClaims(uid, { role });
    logger.info(`Set role '${role}' for user ${uid}`);
    return true;
  } catch (error) {
    logger.error('Error setting user role:', error.message);
    throw error;
  }
};

// Get user by UID
const getUserByUid = async (uid) => {
  try {
    const userRecord = await admin.auth().getUser(uid);
    return userRecord;
  } catch (error) {
    logger.error('Error getting user:', error.message);
    throw error;
  }
};

// Get user by email
const getUserByEmail = async (email) => {
  try {
    const userRecord = await admin.auth().getUserByEmail(email);
    return userRecord;
  } catch (error) {
    logger.error('Error getting user by email:', error.message);
    throw error;
  }
};

// Get user by phone number
const getUserByPhoneNumber = async (phoneNumber) => {
  try {
    const userRecord = await admin.auth().getUserByPhoneNumber(phoneNumber);
    return userRecord;
  } catch (error) {
    logger.error('Error getting user by phone:', error.message);
    throw error;
  }
};

// Delete user
const deleteUser = async (uid) => {
  try {
    await admin.auth().deleteUser(uid);
    logger.info(`Deleted user ${uid}`);
    return true;
  } catch (error) {
    logger.error('Error deleting user:', error.message);
    throw error;
  }
};

// Create custom token (for testing)
const createCustomToken = async (uid) => {
  try {
    const customToken = await admin.auth().createCustomToken(uid);
    return customToken;
  } catch (error) {
    logger.error('Error creating custom token:', error.message);
    throw error;
  }
};

module.exports = {
  initializeFirebase,
  verifyIdToken,
  setUserRole,
  getUserByUid,
  getUserByEmail,
  getUserByPhoneNumber,
  deleteUser,
  createCustomToken,
  admin,
};